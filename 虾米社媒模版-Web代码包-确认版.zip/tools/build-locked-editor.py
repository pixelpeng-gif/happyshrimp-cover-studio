"""Apply the editor customizations to the recovered Web build."""

from pathlib import Path


ASSETS = Path(__file__).resolve().parents[1] / "assets"
original = ASSETS / "index-ZcJhZVT3.js"
output = ASSETS / "editor-locked.js"
bundle = original.read_text(encoding="utf-8")


def replace(old, new, count=1):
    global bundle
    if bundle.count(old) != count:
        raise ValueError(f"Expected {count} occurrence(s) of {old!r} in {original.name}")
    bundle = bundle.replace(old, new)


def replace_between(start, end, replacement=""):
    if bundle.count(start) != 1:
        raise ValueError(f"Expected one block beginning with {start!r}")
    first = bundle.index(start)
    last = bundle.index(end, first + len(start))
    replace(bundle[first:last], replacement)


# Keep asset URLs relative so the editor works under a GitHub Pages project path.
replace('Yx={BASE_URL:"/"}', 'Yx={BASE_URL:"./"}')

# Render the same passive Konva image in the preview stage and the PNG export.
# qx, k1 and F4 are the three themes' original per-ratio defaults.
replace(
    "function $y(f){",
    """function renderLockedLogo(image, layout) {
  return image ? A.jsx(_i, {
    ...layout, image, visible: true, listening: false, draggable: false
  }) : null;
}
function restoreIpDuetLogo(document) {
  document.shared.logoSource = "default";
  document.shared.logoAssetId = null;
  for (const ratio of Object.keys(qx)) {
    document.layouts[ratio].logo = structuredClone(qx[ratio].logo);
  }
  return document;
}
function restoreTemplateFonts(document, templates) {
  for (const [ratio, template] of Object.entries(templates)) {
    const layout = document.layouts[ratio];
    for (const layer of ["mainTitle", "subtitle"]) {
      const preset = template[layer];
      layout[layer] = {
        ...preset, ...layout[layer],
        fontFamily: preset.fontFamily, fontSize: preset.fontSize
      };
    }
  }
  return document;
}
const textResizeAnchors = ["middle-left", "middle-right"];
function textBoxTransformer(selected) {
  return selected === "mainTitle" || selected === "subtitle"
    ? {enabledAnchors: textResizeAnchors, keepRatio: false, flipEnabled: false}
    : {};
}
function resizeTextBox({target: text}) {
  text.width(Math.max(80, text.width() * text.scaleX()));
  text.scale({x: 1, y: 1});
}
function $y(f){""",
)

# Ignore previously saved Logo edits. Keep all other draft migrations in place.
replace(
    ',typeof y.shared.logoAssetId!="string"&&(y.shared.logoAssetId=null);for',
    ";for",
)
replace(
    'bottomEffect.y=364),y}if(a.version!==1)',
    'bottomEffect.y=364),restoreTemplateFonts(restoreIpDuetLogo(y),qx)}if(a.version!==1)',
)
replace('logo:a.logo?Do(a.logo):u.layouts["3:4"].logo,', "")
replace(
    ',u.shared.logoSource=a.logoSource==="upload"?"upload":"default",u.shared.coverAssetId=null,u.shared.logoAssetId=null,u}',
    ",u.shared.coverAssetId=null,restoreTemplateFonts(u,qx)}",
)
replace('["photo","photoFrame","mainTitle","subtitle","logo","bottomGradient"]', '["photo","photoFrame","mainTitle","subtitle","bottomGradient"]')
replace('["centerRing","titleGradient","mainTitle","subtitle","logo"]', '["centerRing","titleGradient","mainTitle","subtitle"]')

# Restore preset type after the existing migrations have read the old layout.
replace('return U4(u.layouts["4:3"]),u}', 'return U4(u.layouts["4:3"]),restoreTemplateFonts(u,k1)}')
replace('a.layout),u.ratio="3:4",u):null}', 'a.layout),u.ratio="3:4",restoreTemplateFonts(u,k1)):null}')
replace('(y.x=100,y.letterSpacing=0),u}function I4', '(y.x=100,y.letterSpacing=0),restoreTemplateFonts(u,F4)}function I4')

# Keep IP 对唱's cover upload, validation and asset cleanup. Existing Logo
# uploads stay in IndexedDB, but the editor no longer loads or writes them.
replace(',kx="happyshrimp-cover-studio:logo"', "")
replace(',Ix="happyshrimp-cover-studio:logo:v:"', "")
replace(
    ',wf=f=>f==="cover"?Wx:Ix,t4=(f,a)=>R1(wf(f),a),e2=async(f,a)=>a?O1(wf(f),a):N1(f==="cover"?Fx:kx)',
    ',loadIpDuetCover=assetId=>assetId?O1(Wx,assetId):N1(Fx)',
)
replace(
    ',o=new Set(a.map(r=>r.shared.logoAssetId).filter(r=>!!r));Promise.all([Tg(wf("cover"),u),Tg(wf("logo"),o)]).catch(()=>{})',
    ";Tg(Wx,u).catch(()=>{})",
)
replace("replaceImage:async(u,o)=>", "replaceCover:async(o)=>")
replace("r=await t4(u,o);", "r=await R1(Wx,o);")
replace(
    'u==="cover"?(p.shared.coverSource="upload",p.shared.coverAssetId=r):(p.shared.logoSource="upload",p.shared.logoAssetId=r)',
    'p.shared.coverSource="upload",p.shared.coverAssetId=r',
)
replace("D1(wf(u),r)", "D1(Wx,r)")
replace("H1(wf(u),r)", "H1(Wx,r)")
replace("update:a,reset:u,replaceImage:o}=qf()", "update:a,reset:u,replaceCover:o}=qf()")
replace("p=S=>async b=>{const x=b.target.files?.[0]", "p=async b=>{const x=b.target.files?.[0]")
replace("await Z1(x),await o(S,x)", "await Z1(x),await o(x)")
replace('onChange:p("cover")', "onChange:p")
replace('()=>e2("cover",u.coverAssetId)', "()=>loadIpDuetCover(u.coverAssetId)")
replace(
    'r=c1(u.logoSource==="upload",u.logoAssetId,()=>e2("logo",u.logoAssetId),fg.defaultLogo,m=>Le().setError("ip-duet",m))||fg.defaultLogo',
    "r=fg.defaultLogo",
)

# Replace the Logo's hit targets and transformer handlers on all three stages.
replace_between(',ut("logo",X,F.logo,', ",A.jsx(A1", ",renderLockedLogo(X,qx[C.ratio].logo)")
replace_between(",fe=(at,Mt,ft)=>Mt&&ft?.visible?", ",G=pt?.visible?")
replace('fe("logo",wt,ot.logo)', "renderLockedLogo(wt,k1[O.ratio].logo)")
replace('keepRatio:R==="logo"||R==="bottomGradient"', 'keepRatio:R==="bottomGradient"')
replace_between(",fe=ft=>wt&&ft.visible?", ",G=b*E")
replace("fe(tt.logo)", "renderLockedLogo(wt,F4[O.ratio].logo)")
replace('keepRatio:R==="logo",', "")

# Title handles still resize the text box horizontally and allow rotation.
# Consume horizontal scale as width so the glyphs stay at the preset size.
for selection, bounds in (("N", "(ht,At)"), ("R", "(at,Mt)"), ("R", "(ft,Et)")):
    replace(f"boundBoxFunc:{bounds}", f"...textBoxTransformer({selection}),boundBoxFunc:{bounds}")
for target, event, layer in (("G", "fe", "bt"), ("et", "Et", "Dt"), ("Dt", "Tt", "se")):
    transform = f"onTransformEnd:{event}=>{{const {target}={event}.target;"
    # Only the text transform among the similarly named node handlers changes font size.
    font_change = f",{layer}.fontSize=Math.max(8,{target}.fontSize()*{target}.scaleY())"
    text_transform = bundle.rindex(transform, 0, bundle.index(font_change))
    handler_prefix = bundle[text_transform:bundle.index(font_change, text_transform)]
    replace(handler_prefix, "onTransform:resizeTextBox," + handler_prefix)
    replace(font_change, "")

# Keep copy input and all other style controls, removing the two preset fields.
for family, main_label, value, event, update in (
    ("HappyShrimp", "造字工房书见体（非商用）", "a", "r", "o"),
    ("HotCreative", "造字工房简圆体", "u", "m", "r"),
    ("MusicChart", "造字工房简圆体", "u", "m", "r"),
):
    font_picker = (
        ',A.jsx(re,{label:"字体",children:A.jsxs("select",{className:"input",'
        f'value:{value}.fontFamily,onChange:{event}=>{update}({{fontFamily:{event}.target.value}}),children:['
        f'A.jsx("option",{{value:"{family}Main",children:"{main_label}"}}),'
        f'A.jsx("option",{{value:"{family}Subtitle",children:"方正悠黑 GBK 509R"}})]'
        '})})'
    )
    replace(font_picker, "")
for value, event, update, occurrences in (("a", "r", "o", 1), ("u", "m", "r", 2)):
    size_picker = (
        'A.jsx(re,{label:"字号",children:A.jsx(ua,{min:"8",max:"260",'
        f'value:{value}.fontSize,onChange:{event}=>{update}({{fontSize:+{event}.target.value}})}})}}),'
    )
    replace(size_picker, "", count=occurrences)
replace('A.jsx("textarea",{className:"input textarea",', 'A.jsx("textarea",{className:"input textarea","aria-label":"文案",', count=3)

# Remove only Logo controls. The top effect, background overlay and reset are
# separate template settings and continue to behave as before.
for owner, value, state in (("r", "S", "b"), ("m", "b", "x")):
    toggle = (
        f'A.jsx(da,{{label:"HappyShrimp Logo",checked:{owner}.logo.visible,'
        f'onChange:{value}=>a({state}=>{{{state}.layouts[{state}.ratio].logo.visible={value}}})}})'
    )
    if owner == "r":
        if bundle.count("," + toggle) != 2:
            raise ValueError("Expected Logo toggles for IP 对唱 and 热点·创意")
        bundle = bundle.replace("," + toggle, "")
    else:
        replace("," + toggle, "")

replace_between(
    'A.jsxs(Ye,{title:"Logo 素材",children:[',
    'A.jsxs(Ha,{className:"full ghost",onClick:y',
    'A.jsxs(Ye,{title:"当前主题",children:[',
)
replace(',"sideLabel","logo"].filter', ',"sideLabel"].filter')
label = ',logo:"HappyShrimp Logo"'
if bundle.count(label) != 3:
    raise ValueError("Expected one Logo option per theme")
bundle = bundle.replace(label, "")

replace(
    ',a==="logo"&&A.jsxs(Ye,{title:"HappyShrimp Logo",children:[A.jsx(MS,{value:m.logo,onChange:y}),A.jsx(da,{label:"显示图层",checked:m.logo.visible,onChange:S=>y({visible:S})})]})',
    "",
)
replace(
    ',a==="logo"&&A.jsxs(Ye,{title:"HappyShrimp Logo",children:[A.jsx(OS,{value:m.logo,onChange:b}),A.jsx(da,{label:"显示图层",checked:m.logo.visible,onChange:x=>b({visible:x})})]})',
    "",
)

replace('||a==="logo")&&Object.assign', ')&&Object.assign')
replace("可编辑完整照片的裁切、主副标题和 Logo。", "可编辑照片裁切和主副标题。")
replace('A.jsx("strong",{children:"选择一个图层"}),', "", count=3)

# Keep the active size visible without giving it the same weight as the heading.
replace(
    'function Ye({title:f,children:a}){return A.jsxs("section",{className:"panel-section",children:[A.jsx("h2",{children:f}),a]})}',
    """function Ye({title, detail, children}) {
  return A.jsxs("section", {
    className: "panel-section",
    children: [
      A.jsxs("h2", {
        children: [title, detail && A.jsx("span", {className: "panel-detail", children: detail})]
      }),
      children
    ]
  });
}""",
)
for heading, theme in (
    ("封面素材", ""),
    ("封面照片", ""),
    ("编辑对象", ""),
    ("编辑对象", "热点·创意 "),
    ("编辑对象", "虾米音乐榜 "),
):
    # The original title is a JavaScript template literal.
    original_heading = f"title:{chr(96)}{heading} · {theme}" + chr(36) + "{f.ratio}" + chr(96)
    replace(original_heading, f'title:"{heading}",detail:f.ratio')

# Match the UI accent on selection outlines and handles in the canvas editor.
replace('"#ff6b35"', '"#ff6636"', count=8)

# Use the supplied white mark on the orange badge in every theme.
replace(
    "function c5(){",
    """function renderBrandMark(className) {
  return A.jsx("span", {
    className, "aria-hidden": true,
    children: A.jsx("img", {src: Sa("assets/brand-mark-white.png"), alt: ""})
  });
}
function c5(){""",
)
replace('A.jsx("span",{className:"brand-mark",children:"HS"})', 'renderBrandMark("brand-mark")', count=3)

# Group the brand and theme picker, centre the ratios, and put dimensions
# beside the canvas they describe.
replace(
    'className:"topbar",children:[A.jsxs("div",{className:"brand",children:[',
    'className:"topbar",children:[A.jsxs("div",{className:"studio-identity",children:[A.jsxs("div",{className:"brand",children:[',
    count=3,
)
for subtitle in ("IP 对唱 · DUET SESSIONS", "热点·创意 · HOT & CREATIVE", "虾米音乐榜 · MUSIC CHART"):
    replace(f',A.jsx("small",{{children:"{subtitle}"}})', "")
for picker in ('A.jsx(K1,{value:a,onChange:u})', 'A.jsx(K1,{value:"hot-creative",onChange:a})', 'A.jsx(K1,{value:"music-chart",onChange:a})'):
    replace(picker, picker + "]})")
replace('A.jsx("span",{children:"当前主题"}),A.jsx("select",{value:f,', 'A.jsx("select",{"aria-label":"当前主题",value:f,')
replace(
    'A.jsxs(Ha,{onClick:C,children:[A.jsx(q1,{size:16}),"重置"]})',
    'A.jsxs(Ha,{onClick:C,className:"toolbar-reset","aria-label":"重置",children:[A.jsx(q1,{size:16}),A.jsx("span",{children:"重置"})]})',
    count=3,
)
replace(
    'A.jsxs("div",{className:"context",children:[A.jsx("span",{children:x.label}),A.jsxs("span",{children:[x.canvas.width,"×",x.canvas.height]})]}),',
    "",
)
replace('A.jsxs("div",{className:"context",children:[A.jsx("span",{children:b.label}),A.jsx("span",{children:b.export1x})]}),', "", count=2)
replace(
    "function c5(){",
    """function renderCanvasSize({width, height}) {
  return A.jsx("div", {className: "canvas-size", children: width + " × " + height + " px"});
}
function c5(){""",
)
for ref, size, scale in (("p", "L", "Nt"), ("m", "st", "bt"), ("m", "X", "G")):
    start = f'className:"canvas-shell",ref:{ref},children:['
    viewport = 'A.jsx("div",{className:"canvas-viewport",'
    canvas = f'children:A.jsx("div",{{className:"canvas-frame",style:{{width:{size}.width*{scale}'
    replace(start + viewport + canvas, start + f"renderCanvasSize({size})," + viewport + canvas)

# Palette thumbnails distinguish the choices visually. Their image labels
# still name each choice for assistive technology.
replace(',A.jsx("span",{children:x})]},x)})})', ']},x)})})', count=2)
replace(',A.jsx("span",{children:E})]},E)})})', ']},E)})})')

# Open the editor itself at every width. The stylesheet adapts the same
# workspace and controls to narrow screens.
replace(
    'return A.jsxs(A.Fragment,{children:[A.jsx(r5,{}),A.jsx("div",{className:"desktop-editor",children:o})]})}',
    'return o}',
)
replace_between("function r5(){", "function f5(")

# Send each toolbar's existing export handler directly to its 2× path.
replace(
    "function c5(){",
    """function renderHighResolutionExport(onExport, size) {
  return A.jsxs(Ha, {
    type: "button", className: "primary", title: "2× · " + size,
    onClick: () => onExport(2),
    children: [A.jsx(B1, {size: 16}), "导出高清 PNG"]
  });
}
function c5(){""",
)
for template, occurrences in (("x", 1), ("b", 2)):
    original_export = (
        'A.jsxs("div",{className:"export-menu",children:['
        'A.jsxs(Ha,{className:"primary",children:[A.jsx(B1,{size:16}),"导出 PNG"]}),'
        'A.jsxs("div",{children:['
        'A.jsxs("button",{type:"button",onClick:()=>f(1),children:["标准 · ",' + template + '.export1x]}),'
        'A.jsxs("button",{type:"button",onClick:()=>f(2),children:["高清 · ",' + template + '.export2x]})]})]})'
    )
    replace(original_export, f"renderHighResolutionExport(f,{template}.export2x)", count=occurrences)

# Remove the manual JSON export from the toolbar. Draft autosave is independent.
replace(',A.jsxs(Ha,{onClick:E,children:[A.jsx(X1,{size:16}),"保存项目"]})', "", count=3)
for theme in ("ip-duet", "hot-creative", "music-chart"):
    filename = bundle.index(f"happyshrimp-{theme}-")
    start = bundle.rindex(",E=()=>{const N=new Blob", 0, filename)
    end = bundle.index(",C=", filename)
    replace(bundle[start:end], "")

output.write_text(bundle, encoding="utf-8")
